class IndexForeignKeysInRisks < ActiveRecord::Migration[5.2]
  def change
    # add_index :risks, :risk_id
  end
end
